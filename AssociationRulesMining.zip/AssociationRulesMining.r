accident_data <- read.csv("accidents.csv")
str(accident_data)
summary(accident_data)
head(accident_data)
#get column names of the data set
colnames <- names(accident_data)
#Start building a file in basket format - one row per transaction and each column value be
# a basket item in the format <column_name>=<column_value>
basket_str <- ""
for ( row in 1:nrow(accident_data)) {
if ( row != 1) {
basket_str <- paste0(basket_str, "\n")
}
basket_str <- paste0(basket_str, row,",")
for (col in 2:length(colnames)) { if ( col != 2) {
basket_str <- paste0(basket_str, ",") }
basket_str <- paste0(basket_str, colnames[col],"=",accident_data[row,col]) }
} write(basket_str,"accidents_basket.csv")

library(arules)

 accidents <- read.transactions("accidents_basket.csv",sep=",") 
 summary(accidents)

  itemFrequencyPlot(accidents,topN=10,type="absolute", col="darkgreen", horiz=TRUE)

  rules <- apriori(accidents, parameter=list(supp=0.1, conf=0.3))

  inspect(rules[1:40])

  #The general form of an association rule is X => Y, where X and Y are two disjoint itemsets. The "support" of an itemset is the number of transactions that contain all the items of that itemset; whereas the support of an association rule is the number of transactions that contain all items of both X and Y. The "confidence" of an association rule is the ratio between its support and the support of X.

#A given association rule X => Y is considered significant and useful, if it has high support and confidence values. The user will specify a threshold value for support and confidence, so that different degrees of significance can be observed based on these threshold values.