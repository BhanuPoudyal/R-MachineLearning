##########################
#LAB 1: Entropy Calculation

# Entropy at the root for the given population : ([50+,50-])
−(50/100)*log2(50/100)−(50/100)*log2(50/100)

#entropy for the two distinct gender segments 
#Male_segment : ([48+,12-])
(-48/60)*log(48/60,2)-(12/60)*log(12/60,2)
#Female_segment : ([2+,38-])
(-2/40)*log(2/40,2)-(38/40)*log(38/40,2)


########################################
#LAB 2: Information Gain

#Calculating information gain based on the variable split

#Split with respect to 'Owning a car'
#Entropy_Ovearll : ([28+,39-])
(-28/67)*log2(28/67)-(39/67)*log2(39/67)

#Entropy_Owning_a_car :([25+,4-])
(-25/29)*log2(25/29)-(4/29)*log2(4/29)
#Entropy_No_car : ([3+,35-])
(-3/38)*log2(3/38)-(35/38)*log2(35/38)

#Information_Gain_for_Owning_a_car
98-((29/67)*57+(38/67)*40)

#Split with respect to 'Gender'
#Entropy_Male : ([19+,21-])
(-19/40)*log2(19/40)-(21/40)*log2(21/40)
#Entropy_Female : ([9+,18-])
(-9/27)*log2(9/27)-(18/27)*log2(18/27)

#Information_Gain_for_Gender
98-((40/67)*99+(21/67)*91)


##########################################
#LAB 3: Decision Tree Building
#Import Data
Ecom_Cust_Survey <- read.csv("Ecom_Cust_Survey.csv")

dim(Ecom_Cust_Survey)
names(Ecom_Cust_Survey)

#Need the library rpart
#install.packages("rpart")
library(rpart)

#Building Tree Model
Ecom_Tree<-rpart(Overall_Satisfaction~Region+ Age+ Order.Quantity+Customer_Type+Improvement.Area, method="class", data=Ecom_Cust_Survey, control=rpart.control(minsplit=30))
Ecom_Tree

#Plotting the trees
plot(Ecom_Tree, uniform=TRUE)
text(Ecom_Tree, use.n=TRUE, all=TRUE)

#A better looking tree
library(rattle)
fancyRpartPlot(Ecom_Tree,palettes=c("Greys", "Oranges"))

########################################################
## LAB 4 : Tree Validation
Ecom_pred<-predict(Ecom_Tree, type="class")

#Confusion Matrix
conf_matrix<-table(Ecom_pred,Ecom_Cust_Survey$Overall_Satisfaction)
conf_matrix

#Accuracy
accuracy<-(conf_matrix[1,1]+conf_matrix[2,2])/(sum(conf_matrix))
accuracy

############################################################################ 
##LAB 5 : The problem of overfitting
#Importing data
train <- read.csv("Train_data.csv")
test<-read.csv("Test_data.csv")

dim(train)
dim(test)
names(train)

#Building a Tree Model
library(rpart)
Sample_tree<-rpart(Bought~Gender+Age, method="class", data=train, control=rpart.control(minsplit=2))
Sample_tree

#Plotting the tree
library(rattle)
fancyRpartPlot(Sample_tree,palettes=c("Greys", "Oranges"))

#Tree Validation
#Accuracy On the training data
sample_pred<-predict(Sample_tree, type="class")

#Accuracy and Confusion Matrix
conf_matrix<-table(sample_pred,train$Bought)
conf_matrix

accuracy<-(conf_matrix[1,1]+conf_matrix[2,2])/(sum(conf_matrix))
accuracy

#Accuracy On the test data
test_pred<- predict(Sample_tree, test,type="class")

#Accuracy and Confusion Matrix
conf_matrix<-table(test_pred,test$Bought)
conf_matrix

accuracy<-(conf_matrix[1,1]+conf_matrix[2,2])/(sum(conf_matrix))
accuracy

############################################################################ 
# LAB 6: Pruning the tree and choosing Cp

#Changing Cp
Sample_tree_1<-rpart(Bought~Gender+Age, method="class", data=train, control=rpart.control(minsplit=2, cp=0.1))
Sample_tree_1

#Plotting
library(rattle)
fancyRpartPlot(Sample_tree_1,palettes=c("Greys", "Oranges"))

#Tree Validation
#Accuracy on the training data
sample_pred <- predict(Sample_tree_1, type="class")

#Calculation of Accuracy and Confusion Matrix
conf_matrix <- table(sample_pred, train$Bought)
conf_matrix

accuracy <- (conf_matrix[1,1]+conf_matrix[2,2])/(sum(conf_matrix))
accuracy

#Accuracy On the test data
test_pred <- predict(Sample_tree_1, test, type="class")

#Calculation of Accuracy and Confusion Matrix
conf_matrix <- table(test_pred, test$Bought)
conf_matrix

accuracy <- (conf_matrix[1,1]+conf_matrix[2,2])/(sum(conf_matrix))
accuracy

#Cp display the results
printcp(Sample_tree)
#Cross-validation results
plotcp(Sample_tree)

Sample_tree_2<-rpart(Bought~Gender+Age, method="class", data=train, control=rpart.control(minsplit = 2, cp=0.23))
Sample_tree_2

#Plotting
fancyRpartPlot(Sample_tree_2, palettes=c("Greys", "Oranges"))

#We can either build a new tree or Prune the old tree
Sample_tree <- rpart(Bought~Gender+Age, method="class", data=train, control=rpart.control(minsplit=2))
Sample_tree

#Plotting
library(rattle)
fancyRpartPlot(Sample_tree, palettes = c("Greys", "Oranges"))

Pruned_tree <- prune(Sample_tree, cp=0.23)
Pruned_tree

fancyRpartPlot(Pruned_tree, palettes = c("Greys", "Oranges"))


############################################################################
# LAB 7: Tree Building and Model Selection

#Importing Fiberbits data
Fiberbits <- read.csv("Fiberbits.csv")
names(Fiberbits)

#Building a Tree Model
library(rpart)
Fiber_bits_tree <- rpart(active_cust~., method = "class", control=rpart.control(minsplit = 30, cp=0.001), data = Fiberbits)
Fiber_bits_tree
fancyRpartPlot(Fiber_bits_tree)

#Analyzing the Tree
printcp(Fiber_bits_tree) 
plotcp(Fiber_bits_tree) 

#Pruning
Fiber_bits_tree_1<-prune(Fiber_bits_tree, cp=0.0081631)
Fiber_bits_tree_1
fancyRpartPlot(Fiber_bits_tree_1)

#Analyzing the tree
printcp(Fiber_bits_tree_1) 
plotcp(Fiber_bits_tree_1) 

#Pruning Further
Fiber_bits_tree_2<-prune(Fiber_bits_tree, cp=0.0239316)
Fiber_bits_tree_2
fancyRpartPlot(Fiber_bits_tree_2)

#Analyzing the tree
printcp(Fiber_bits_tree_2) 
plotcp(Fiber_bits_tree_2) 

#Prediction using the model
conf_matrix<-table(predict(Fiber_bits_tree_2, type="class"),Fiberbits$active_cust)
conf_matrix
accuracy<-(conf_matrix[1,1]+conf_matrix[2,2])/(sum(conf_matrix))
accuracy