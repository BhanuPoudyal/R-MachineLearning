#################################################
#Lab: Basic contents of the data
#################################################

#Import "Give me some Credit\cs-training.csv" 
loans<- read.csv("/Give me some Credit/cs-training.csv")
View(loans)

#What are number of rows and columns
dim(loans)

#Are there any suspicious variables?
names(loans)

#Are all the variable names correct?
names(loans)

#Display the variable formats
str(loans)

#Print the first 10 observations
head(loans, n=10)

#Do we have any unique identifier?
names(loans)

#Do the text and numeric variables have meaningful data?

#Are there some coded values in the data?
#Do all the variables appear to have data

#################################################
#Lab: Frequencies
#################################################

#What are the categorical and discrete variables? What are the continues variables.
str(loans)
head(loans)

#Find the frequencies of all class variables in the data 
names(loans)
table(loans$SeriousDlqin2yrs)
table(loans$age)
table(loans$NumberOfTime30.59DaysPastDueNotWorse)
table(loans$NumberOfOpenCreditLinesAndLoans)
table(loans$NumberOfTimes90DaysLate)
table(loans$NumberRealEstateLoansOrLines)
table(loans$NumberOfTime60.89DaysPastDueNotWorse)
table(loans$NumberOfDependents)


#Are there any   variables with missing values?
#Are there any default values?
#Can you identify the variables with outliers?
#Are there any variables with oth issues?

#################################################
#LAB: Continuous variables summary
#################################################

#List down the continuous variables
str(loans)
head(loans)

#Find summary statistics for each variable. Min, Max, Median, Mean, sd, Var
summary(loans$RevolvingUtilizationOfUnsecuredLines)
summary(loans$MonthlyIncome)

var(loans$RevolvingUtilizationOfUnsecuredLines)
var(loans$MonthlyIncome)
var(loans$MonthlyIncome,na.rm = TRUE)

sd(loans$RevolvingUtilizationOfUnsecuredLines)
sd(loans$MonthlyIncome)
sd(loans$MonthlyIncome,na.rm = TRUE)

library(psych)
describe(loans$RevolvingUtilizationOfUnsecuredLines)
describe(loans$MonthlyIncome)


#Find Quartiles for each of the variables
summary(loans$RevolvingUtilizationOfUnsecuredLines)
summary(loans$MonthlyIncome)

#Create Box plots and identify outliers
boxplot(loans$RevolvingUtilizationOfUnsecuredLines)
boxplot(loans$MonthlyIncome)

library(ggplot2)
ggplot(loans, aes(y=RevolvingUtilizationOfUnsecuredLines, x = 1)) + geom_boxplot()
ggplot(loans, aes(y=MonthlyIncome, x = 1)) + geom_boxplot()

#Find the percentage of missing values
sum(is.na(loans$MonthlyIncome))
sum(is.na(loans$MonthlyIncome))/nrow(loans)


#Find Percentiles and find percentage of outliers, if any P1, p5,p10,q1(p25),q3(p75), p90,p99 
util_percentiles<-round(quantile(loans$RevolvingUtilizationOfUnsecuredLines,c(0.05, 0.1, 0.25, 0.5, 0.75, 0.80, 0.9,0.91,0.95,0.96,0.97,0.975,0.98,0.99,1)),2)
util_percentiles

#################################################
#LAB: Data Cleaning Scenario-1
#################################################
#What percent are missing values in RevolvingUtilizationOfUnsecuredLines?
ggplot(loans, aes(y=RevolvingUtilizationOfUnsecuredLines, x = 1)) + geom_boxplot()

#Get the detailed percentile distribution
util_percentiles<-round(quantile(loans$RevolvingUtilizationOfUnsecuredLines,c(0.05, 0.1, 0.25, 0.5, 0.75, 0.80, 0.9,0.91,0.95,0.96,0.97,0.975,0.98,0.99,1)),2)
util_percentiles


#Clean the variable, and create a new variable by removing all the issues

#If utilization is more than 1 then it can be replaced by median
median_util<-median(loans$RevolvingUtilizationOfUnsecuredLines)
loans$util_new<-ifelse(loans$RevolvingUtilizationOfUnsecuredLines>1,median_util,loans$RevolvingUtilizationOfUnsecuredLines)

#Box_plot on cleaned variable
ggplot(loans, aes(y=util_new, x = 1)) + geom_boxplot()

# percentile distribution for new variable
util_percentiles1<-round(quantile(loans$util_new,c(0.05, 0.1, 0.25, 0.5, 0.75, 0.80, 0.9,0.91,0.95,0.96,0.97,0.975,0.98,0.99,1)),2)
util_percentiles1


#################################################
#LAB: Data Cleaning Scenario-2
#################################################

#What is the issue with NumberOfTime30_59DaysPastDueNotW
#Draw a frequency table
freq_table_30dpd<-table(loans$NumberOfTime30.59DaysPastDueNotWorse)
freq_table_30dpd

#One month defaults frequency can't be beyond 24 in last 24 months

#What percent of the values are erroneous?
freq_table_30dpd[14:length(freq_table_30dpd)]
sum(freq_table_30dpd[14:length(freq_table_30dpd)])/sum(freq_table_30dpd)

#Clean the variable- Look at the cross tab of variable vs target. Impute based on target .
#Cross tab with target
cross_tab_30dpd_target<-table(loans$NumberOfTime30.59DaysPastDueNotWorse,loans$SeriousDlqin2yrs)
cross_tab_30dpd_target

#Cross tab row Percentages
cross_tab_30dpd_target_percent<-round(prop.table(cross_tab_30dpd_target, 1),2)
cross_tab_30dpd_target_percent

data.frame(Freq_0=cross_tab_30dpd_target[,1],Freq_1=cross_tab_30dpd_target[,2],Pert_0=cross_tab_30dpd_target_percent[,1],Pert_1=cross_tab_30dpd_target_percent[,2])

#Percentage of 0 and 1 are of 98 is near to percentages of 6. 
#Replacing error values with 6
loans$num_30_59_dpd_new<-ifelse(loans$NumberOfTime30.59DaysPastDueNotWorse>12,6,loans$NumberOfTime30.59DaysPastDueNotWorse)

#Create frequency table for cleaned variable
table(loans$num_30_59_dpd_new)

#################################################
#Data Cleaning Scenario-3
#################################################
#Find the missing value percentage in monthly income
sum(is.na(loans$MonthlyIncome))
sum(is.na(loans$MonthlyIncome))/nrow(loans)

#Create an indicator variable for missing and non-missing
loans$MonthlyIncome_ind<-ifelse(is.na(loans$MonthlyIncome), "Missing", "Non-Missing")
table(loans$MonthlyIncome_ind)

#Replace the missing values with median
median_income<-median(loans$MonthlyIncome, na.rm = TRUE)
median_income
loans$MonthlyIncome_new<-ifelse(is.na(loans$MonthlyIncome), median_income, loans$MonthlyIncome)
sum(is.na(loans$MonthlyIncome_new))
