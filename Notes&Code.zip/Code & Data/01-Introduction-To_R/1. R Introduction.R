#1 R � Quick warmup
68+28
134*456
sqrt(119)
log(10)
exp(5)
help(log)

#2 The Assign Operator
x<-7
y<-68+28
z<-134*456
k<-sqrt(119)

x
y
z
k

#3 Working with R
x <- rnorm(1000,mean=20,sd=5) 
x

mean(x)
m <- mean(x)
m

s<-sd(x)
s

#4 Installing packages
x <- rnorm(1000,mean=20,sd=5) 
y <- rnorm(1000,mean=15,sd=3) 
z <- rnorm(1000,mean=25,sd=8) 
scatterplot3d(x,y,z)

install.packages("scatterplot3d")
library(scatterplot3d)
scatterplot3d(x,y,z)

#5 R Vectors 

name<-"March"
is.vector(name)
Age<-29
is.vector(Age)

Age <- c(15, 17, 16, 15, 16)
English<- c(40, 56, 30, 68, 35)
Science<- c(85, 80, 74, 39, 65)
Name<- c("John", "Bob", "Kevin", "Smith", "Rick")

is.vector(Age)
is.vector(English)
is.vector(Name)

Age+3
English1<- English+10
English1<-80
Total<- English1 + Science 
Total
Age/Total

x <- rnorm(1000,mean=20,sd=5) 
x-mean(x)

Age
Age[3]
Age[2:5]
Age[-2]
Age[3]<-19
Age

class(Age)
class(Name)

#6 R Data frames
students<-data.frame(Name, Age, English, Science)
students

Profile_data<- data.frame(Name, Age)
Profile_data

#c() it will not create a data frame, we need to use data.frame function
students1<-c(Name, Age, English, Science)
students1

str(students)
str(students1)

# Accessing R Data Frames

students$Name
students$English
students$Science

students["Science"]
students["Name"]
          
students[1,]
students[,1]
students[,2:4]
students[,-1]
students[-1,]
students[,c(1,4)]
          

#Difference in Accessed Data frame elements
x<-students$Name
y<-students["Name"]
z<-students[,1]

x
y
z

str(x)
str(y)
str(z)

# Built-in Data Frames

data()
AirPassengers 
?cars

#8 Lists
x <- c(1:20)
y <- FALSE
z<-"Mike"
k<-30
l<-students
Disc<-"This is a list of all my R elements"

str(x)
str(y)
str(z)
str(k)
str(l)
mylist<-list(Disc,x,y,z,k,l)

#Accessing Lists
str(mylist)
mylist
mylist[1]
mylist[2]
mylist[[2]][1]

#Lists Example
cars
reg_model<-lm(cars$dist~cars$speed)
reg_model
str(reg_model)
reg_model[1]
reg_model[2]
reg_model[7]
reg_model[[7]][1]
reg_model[[7]][2]

#Factors Example
gender<-c("Male","Female")
gender
gender1<-factor(gender)
str(gender1)

result<-c(1,0)
result
str(result)
result1<-factor(result)
str(result1)

#Comments
#CO2   data is in datasets()
CO2
CO2$Type
CO2$Type #Printing a column

#My First R Program
Income<- c(5500, 6700, 8970, 5634)
Tax<-0.2
Year<-2015
Company<-"Intel" 
Net_income<- Income*(1-Tax)
Emp_name<-c("Redd", "Kenn", "Finn", "Scott")
Emp_database<-data.frame(Net_income, Emp_name)
Emp_db_list<-list(Income,Tax, Year, Company, Emp_database)


#R- Functions
y<-abs(-20)
x<-sum(y+5)
Z<-log(x)
round(Z,1)
cust_id<-"Cust1233416"
id<-substr(cust_id, 5,10)
Up=toupper(cust_id)
grep(4, cust_id) 

#R Most common errors

myvar <- c(15, 17, 16, 15, 16)
Myvar
Error: object 'Myvar' not found

qplot(mpg, wt, data=mtcars)
Error: could not find function "qplot"

library(ggplot2)
Error in library(ggplot2) : there is no package called �ggplot2�

install.packages("ggplot2")
library(ggplot2)
qplot(mpg, wt, data=mtcars)

Name<- c("John", "Bob", "Kevin", "Smith", "Rick")
Name+1


#help home
help.start()

#Help on specific functions and usage
?substr()
help(substr)